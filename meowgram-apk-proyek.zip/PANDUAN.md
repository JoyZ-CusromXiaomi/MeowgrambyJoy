# Panduan membuat APK Meowgram

Kamu tidak perlu menginstal Android Studio. Semua dikerjakan lewat browser di HP atau laptop.
Siapkan: akun Google (untuk Firebase) dan akun GitHub (gratis).

## A. Buat proyek Firebase

1. Buka https://console.firebase.google.com lalu masuk dengan akun Google.
2. Tekan **Create a project** (Buat proyek), beri nama `meowgram`. Google Analytics boleh dimatikan.
3. Di menu kiri pilih **Build > Authentication > Get started**. Di tab **Sign-in method**, aktifkan **Email/Password**.
4. Di menu kiri pilih **Build > Firestore Database > Create database**. Pilih lokasi terdekat (misalnya `asia-southeast2` Jakarta), mode **Production**.
5. Setelah dibuat, buka tab **Rules**. Hapus isinya, tempel seluruh isi berkas `firestore.rules` dari folder ini, lalu tekan **Publish**. Langkah ini penting supaya data tiap akun aman.
6. Tekan ikon roda gigi di samping Project Overview, pilih **Project settings**. Di bagian **Your apps**, tekan ikon web `</>`, beri nama `meowgram-web`, tekan **Register app**.
7. Akan muncul kode `firebaseConfig` berisi `apiKey`, `authDomain`, dan seterusnya. Salin nilainya.

## B. Isi konfigurasi

Buka berkas `src/firebase-config.js` dan ganti semua tulisan `ISI_...` dengan nilai dari langkah A7.
Konfigurasi ini memang boleh ada di dalam aplikasi. Keamanan data dijaga oleh aturan Firestore (A5).

## C. Upload ke GitHub dan bangun APK

1. Buka https://github.com, masuk, tekan **New repository**, beri nama `meowgram`, pilih **Private**, lalu **Create**.
2. Tekan **uploading an existing file**, lalu upload seluruh isi folder proyek ini (termasuk folder `.github`, `src`, dan semua berkas lain). Tekan **Commit changes**.
   Folder `.github` kadang tersembunyi dan tidak ikut terupload. Jika tab Actions kosong, tekan **Add file > Create new file**, ketik nama `.github/workflows/build-apk.yml`, lalu tempel isi berkas itu dan **Commit**.
   Mengunggah banyak berkas lebih mudah dari laptop atau komputer daripada dari HP.
3. Buka tab **Actions**. Pembangunan APK berjalan otomatis dan butuh sekitar 5 sampai 10 menit. Kalau tidak jalan, pilih **Build APK** lalu **Run workflow**.
4. Setelah ada tanda centang hijau, buka hasil build tersebut. Di bagian **Artifacts**, unduh **meowgram-apk** (berupa zip), lalu ekstrak untuk mendapatkan `app-debug.apk`.

## D. Pasang di HP Android

1. Kirim `app-debug.apk` ke HP (WhatsApp, Drive, atau kabel).
2. Buka berkasnya. Jika Android meminta izin **pasang dari sumber tidak dikenal**, izinkan untuk aplikasi yang kamu pakai membukanya.
3. Buka Meowgram, daftarkan kucingmu, dan mulai coba.

## Catatan penting

- Foto postingan diperkecil otomatis dan disimpan langsung di Firestore, jadi tidak perlu paket berbayar. Cocok untuk ratusan pengguna. Kalau pengguna sudah banyak, pindahkan foto ke penyimpanan khusus.
- Firebase gratis (paket Spark) punya batas harian baca dan tulis. Untuk tahap awal sudah cukup.
- Setiap kali kamu mengubah berkas di GitHub, APK dibangun ulang otomatis.
- APK ini versi debug untuk dibagikan langsung. Untuk masuk Play Store, dibutuhkan APK/AAB rilis dan akun pengembang Google Play (biaya sekali sekitar US$25).
- Notes hilang otomatis setelah 24 jam. Lokasi di Notes hanya label (misalnya "Di atas kulkas"), bukan GPS, supaya posisi rumah tidak terbuka.
