import './style.css';
import cfg from './firebase-config.js';
import { initializeApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged } from 'firebase/auth';
import { getFirestore, doc, getDoc, setDoc, updateDoc, deleteDoc, collection, query, where, orderBy, limit, getDocs, addDoc, onSnapshot, arrayUnion, arrayRemove, getCountFromServer } from 'firebase/firestore';

const configured = !!(cfg && cfg.apiKey && cfg.apiKey.indexOf('ISI') !== 0);
let auth = null, db = null;
if (configured) { const app = initializeApp(cfg); auth = getAuth(app); db = getFirestore(app); }

/* ---------- ikon dan gambar kucing (SVG) ---------- */
const IC = {
  home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h5v-6h4v6h5V10"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
  plus: '<rect x="3" y="3" width="18" height="18" rx="5"/><path d="M12 8v8M8 12h8"/>',
  dm: '<path d="M21 4L3 11l7 3 3 7z"/><path d="M10 14l11-10"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>',
  heart: '<path d="M12 20s-8-5-8-11a4.5 4.5 0 018-2.8A4.5 4.5 0 0120 9c0 6-8 11-8 11z"/>',
  comment: '<path d="M21 12a8 8 0 01-11.6 7.1L3 20l1-4.6A8 8 0 1121 12z"/>',
  moon: '<path d="M20 14.5A8 8 0 019.5 4 8 8 0 1020 14.5z"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5"/>',
  back: '<path d="M15 5l-7 7 7 7"/>',
  pin: '<path d="M12 21s7-6 7-11a7 7 0 10-14 0c0 5 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/>',
  music: '<path d="M9 18V5l11-2v13"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/>'
};
const ic = n => '<svg viewBox="0 0 24 24" aria-hidden="true">' + IC[n] + '</svg>';
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const $ = id => document.getElementById(id);

function face(c, prop, bgOverride) {
  const fur = c.fur || '#f0a04b', belly = c.belly || '#fff1dc', bg = bgOverride || c.bg || '#cfe3ff';
  let s = '<svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice"><rect width="100" height="100" fill="' + bg + '"/>';
  if (prop === 'kardus') s += '<rect x="14" y="58" width="72" height="34" rx="4" fill="#c99a62"/><rect x="14" y="58" width="72" height="8" fill="#b5864f"/>';
  s += '<path d="M20 46L24 12L47 30Z" fill="' + fur + '"/><path d="M80 46L76 12L53 30Z" fill="' + fur + '"/>';
  s += '<path d="M26 38L28 22L40 31Z" fill="#f4a3b4"/><path d="M74 38L72 22L60 31Z" fill="#f4a3b4"/>';
  s += '<ellipse cx="50" cy="55" rx="33" ry="29" fill="' + fur + '"/>';
  if (c.stripe) s += '<path d="M50 27v10M42 29l2 8M58 29l-2 8" stroke="' + belly + '" stroke-width="3" stroke-linecap="round" opacity=".55"/>';
  s += '<ellipse cx="50" cy="66" rx="15" ry="11" fill="' + belly + '"/>';
  s += '<ellipse cx="37.5" cy="52" rx="4.6" ry="5.6" fill="#fff"/><ellipse cx="62.5" cy="52" rx="4.6" ry="5.6" fill="#fff"/>';
  s += '<ellipse cx="38" cy="53" rx="2.6" ry="4" fill="#1d1b19"/><ellipse cx="62" cy="53" rx="2.6" ry="4" fill="#1d1b19"/>';
  s += '<circle cx="39" cy="51" r="1.1" fill="#fff"/><circle cx="63" cy="51" r="1.1" fill="#fff"/>';
  s += '<path d="M46.5 62h7l-3.5 4z" fill="#f08aa0"/><path d="M50 66v3M50 69c-2 2-5 2-6.5 0M50 69c2 2 5 2 6.5 0" stroke="#3a2f2b" stroke-width="1.3" fill="none" stroke-linecap="round"/>';
  s += '<path d="M30 62l-14-3M30 66l-14 3M70 62l14-3M70 66l14 3" stroke="#fff" stroke-opacity=".8" stroke-width="1.2" stroke-linecap="round"/>';
  if (prop === 'benang') s += '<circle cx="78" cy="82" r="11" fill="#ff6b8a"/><path d="M69 80c6 3 12 3 19-1M70 86c6 2 11 2 17-2" stroke="#fff" stroke-opacity=".6" stroke-width="1.5" fill="none"/>';
  if (prop === 'ikan') s += '<g transform="translate(60 76)"><ellipse cx="12" cy="8" rx="13" ry="7" fill="#7fc4ff"/><path d="M24 8l9-6v12z" fill="#7fc4ff"/><circle cx="6" cy="6" r="1.6" fill="#1d1b19"/></g>';
  if (prop === 'hati') s += '<path d="M80 22c-5-6-14 0-8 7l8 7 8-7c6-7-3-13-8-7z" fill="#ff5c7a"/>';
  return s + '</svg>';
}
const av = (c, px) => '<span class="av" style="width:' + px + 'px;height:' + px + 'px">' + face(c) + '</span>';

const BG = ['#cfe3ff', '#ffe3b8', '#d9f2d0', '#ffd6e0', '#e6dcff', '#fff1a8'];
const FUR = [['#f0a04b', '#fff1dc'], ['#2b2b2e', '#ffffff'], ['#8e98a6', '#d9dee5'], ['#f3f1ee', '#ffffff'], ['#8a6a4f', '#e9d8c4'], ['#b9a58c', '#efe6d8']];
const MUSIC = ['Meong Meong - Pus Band', 'Bulu Halus - Mpus Trio', 'Rebahan - Kucing Santai', 'Cakar Cakar Dance - DJ Whiskers'];
const PLACES = ['Di atas kulkas', 'Bawah kasur', 'Jendela dapur', 'Dalam kardus', 'Atas lemari', 'Sofa ruang tamu', 'Teras depan'];
const DAY = 24 * 60 * 60 * 1000;

/* ---------- state ---------- */
const st = { ready: false, uid: null, me: null, tab: 'home', home: 'fyp', chat: null, other: null, q: '', authMode: 'register', follows: new Set(), users: {}, userList: [], regFur: 0 };
let tok = 0, unsubChat = null, registering = false, draft = {};

function toast(t) { const e = $('toast'); e.textContent = t; e.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(() => { e.hidden = true; }, 2200); }
function setTheme(t) { document.documentElement.setAttribute('data-theme', t); st.theme = t; try { localStorage.setItem('mg-theme', t); } catch (e) { /* abaikan */ } }
const isDark = () => st.theme ? st.theme === 'dark' : window.matchMedia('(prefers-color-scheme: dark)').matches;
const cid = peer => [st.uid, peer].sort().join('_');
const noteFresh = n => n && n.at && (Date.now() - n.at) < DAY;
const likeCount = p => (p.likedBy || []).length;

async function getUser(id, force) {
  if (!force && st.users[id]) return st.users[id];
  const s = await getDoc(doc(db, 'users', id));
  if (!s.exists()) return null;
  st.users[id] = Object.assign({ id }, s.data());
  return st.users[id];
}
function errText(e) {
  const c = (e && e.code) || '';
  const m = {
    'auth/email-already-in-use': 'Email ini sudah terdaftar. Silakan masuk.',
    'auth/invalid-email': 'Format email belum benar.',
    'auth/weak-password': 'Kata sandi minimal 6 karakter.',
    'auth/invalid-credential': 'Email atau kata sandi salah.',
    'auth/wrong-password': 'Email atau kata sandi salah.',
    'auth/user-not-found': 'Email atau kata sandi salah.',
    'auth/too-many-requests': 'Terlalu banyak percobaan. Coba lagi sebentar lagi.',
    'auth/network-request-failed': 'Tidak ada koneksi internet.',
    'permission-denied': 'Tidak diizinkan. Coba masuk ulang.',
    'unavailable': 'Tidak ada koneksi internet.'
  };
  return m[c] || 'Terjadi kesalahan. Coba lagi.';
}

/* ---------- tampilan ---------- */
function noteBubble(n, mine) {
  if (!noteFresh(n)) return '<div class="bubble empty">' + (mine ? 'Tambah note' : '') + '</div>';
  let h = '<div class="bubble">' + (n.text ? '<span>' + esc(n.text) + '</span>' : '');
  if (n.music) h += '<small>' + ic('music') + esc(n.music) + '</small>';
  if (n.place) h += '<small>' + ic('pin') + esc(n.place) + '</small>';
  return h + '</div>';
}
function postHtml(p, a) {
  const k = p.id, liked = (p.likedBy || []).indexOf(st.uid) > -1, n = likeCount(p);
  const mine = p.uid === st.uid;
  const fol = (mine || st.follows.has(p.uid)) ? '' : '<button class="btn" data-act="follow" data-id="' + p.uid + '">Ikuti</button>';
  const pic = p.img ? '<img src="' + p.img + '" alt="Foto dari ' + esc(a.name) + '" loading="lazy">' : face(a, p.prop, p.bg);
  return '<article class="post"><div class="post-head"><button data-act="open" data-id="' + p.uid + '" aria-label="Buka profil ' + esc(a.name) + '">' + av(a, 36) + '</button>' +
    '<div class="grow"><div class="name">' + esc(a.name) + '</div><div class="sub">' + esc(a.breed) + '</div></div>' + fol + '</div>' +
    '<div class="pic">' + pic + '</div>' +
    '<div class="actions"><button class="icon-btn' + (liked ? ' liked' : '') + '" data-act="like" data-k="' + k + '" data-l="' + (liked ? 1 : 0) + '" aria-label="Suka" aria-pressed="' + liked + '">' + ic('heart') + '</button>' +
    '<button class="icon-btn" data-act="toast" data-t="Komentar menyusul di versi berikutnya" aria-label="Komentar">' + ic('comment') + '</button>' +
    (mine ? '<button class="icon-btn" data-act="delpost" data-k="' + k + '" aria-label="Hapus postingan" style="margin-left:auto;font-size:12.5px;font-weight:800;width:auto;padding:0 12px;border-radius:999px">Hapus</button>' : '') + '</div>' +
    '<div class="meta"><div class="name">' + n + ' suka</div><div><b>' + esc(a.name) + '</b> ' + esc(p.cap) + '</div></div></article>';
}
async function withAuthors(posts) {
  const ids = [...new Set(posts.map(p => p.uid))];
  await Promise.all(ids.map(i => getUser(i)));
  return posts.filter(p => st.users[p.uid]).map(p => postHtml(p, st.users[p.uid]));
}
async function vHome() {
  const tab = st.home;
  let h = '<div class="tabs" role="tablist"><button role="tab" data-act="htab" data-v="feed" aria-selected="' + (tab === 'feed') + '">Mengikuti</button><button role="tab" data-act="htab" data-v="fyp" aria-selected="' + (tab === 'fyp') + '">Untuk Kamu</button></div>';
  let snap;
  if (tab === 'feed') {
    const ids = [st.uid].concat([...st.follows]).slice(0, 30);
    snap = await getDocs(query(collection(db, 'posts'), where('uid', 'in', ids), limit(50)));
  } else {
    snap = await getDocs(query(collection(db, 'posts'), orderBy('at', 'desc'), limit(30)));
    if (!st.follows.size) h += '<div class="banner"><b>Kamu belum mengikuti siapa pun.</b> Ini FYP berisi akun kucing terbaru. Ikuti yang kamu suka agar berandamu terisi.</div>';
  }
  const posts = snap.docs.map(d => Object.assign({ id: d.id }, d.data())).sort((a, b) => (b.at || 0) - (a.at || 0));
  const items = await withAuthors(posts);
  if (!items.length) return h + '<div class="empty-state"><b>Belum ada postingan</b>' + (tab === 'feed' ? 'Akun yang kamu ikuti belum memposting apa pun.' : 'Jadilah yang pertama memposting, lalu ajak teman pemilik kucing bergabung.') + '<br><button class="btn" data-act="postsheet">Buat postingan</button></div>';
  return h + items.join('');
}
function matchUser(u, q) { return !q || (u.name || '').toLowerCase().includes(q) || (u.breed || '').toLowerCase().includes(q); }
function resultsHtml(q) {
  const res = st.userList.filter(u => u.id !== st.uid && matchUser(u, q));
  if (!res.length) return '<div class="empty-state"><b>Tidak ada kucing ditemukan</b>' + (q ? 'Coba kata kunci lain, misalnya nama ras.' : 'Belum ada akun lain. Ajak temanmu mendaftar.') + '</div>';
  return '<div class="section-label">' + (q ? 'Hasil pencarian' : 'Akun kucing') + '</div>' + res.map(c =>
    '<div class="row"><button data-act="open" data-id="' + c.id + '" aria-label="Buka profil ' + esc(c.name) + '">' + av(c, 48) + '</button><div class="grow"><div class="name">' + esc(c.name) + '</div><div class="sub">' + esc(c.breed) + '</div></div>' +
    (st.follows.has(c.id) ? '<button class="btn ghost" data-act="follow" data-id="' + c.id + '">Mengikuti</button>' : '<button class="btn" data-act="follow" data-id="' + c.id + '">Ikuti</button>') + '</div>').join('');
}
async function vSearch() {
  const s = await getDocs(query(collection(db, 'users'), limit(100)));
  st.userList = s.docs.map(d => { const u = Object.assign({ id: d.id }, d.data()); st.users[d.id] = u; return u; });
  return '<div class="search"><input id="q" type="search" placeholder="Cari kucing atau ras" value="' + esc(st.q) + '" autocomplete="off"></div><div id="results">' + resultsHtml(st.q.trim().toLowerCase()) + '</div>';
}
async function vDm() {
  const s = await getDocs(query(collection(db, 'chats'), where('members', 'array-contains', st.uid)));
  const threads = s.docs.map(d => d.data()).filter(c => c.lastText).sort((a, b) => (b.lastAt || 0) - (a.lastAt || 0));
  const peers = threads.map(t => t.members.find(m => m !== st.uid));
  const noteIds = [...new Set([...st.follows, ...peers])];
  await Promise.all([...noteIds, ...peers].map(i => getUser(i, true)));
  let h = '<div class="notes"><button class="note" data-act="notesheet" aria-label="Buat note">' + noteBubble(st.me.note, true) + av(st.me, 56) + '<span class="sub">Notemu</span></button>';
  noteIds.map(i => st.users[i]).filter(u => u && noteFresh(u.note)).forEach(u => {
    h += '<button class="note" data-act="chat" data-id="' + u.id + '" aria-label="Chat dengan ' + esc(u.name) + '">' + noteBubble(u.note) + av(u, 56) + '<span class="sub">' + esc(u.name) + '</span></button>';
  });
  h += '</div><div class="section-label">Pesan</div>';
  if (!threads.length) h += '<div class="empty-state"><b>Belum ada pesan</b>Buka profil kucing lain, lalu tekan Kirim pesan.</div>';
  threads.forEach((t, i) => {
    const u = st.users[peers[i]]; if (!u) return;
    h += '<button class="thread" data-act="chat" data-id="' + u.id + '">' + av(u, 52) + '<div class="grow"><div class="name">' + esc(u.name) + '</div><div class="sub" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + (t.lastFrom === st.uid ? 'Kamu: ' : '') + esc(t.lastText) + '</div></div></button>';
  });
  return h;
}
function gridHtml(posts, a) {
  return '<div class="grid">' + posts.map(p => '<div class="pic">' + (p.img ? '<img src="' + p.img + '" alt="Postingan ' + esc(a.name) + '" loading="lazy">' : face(a, p.prop, p.bg)) + '</div>').join('') + '</div>';
}
async function profileData(id) {
  const [ps, fr, fg] = await Promise.all([
    getDocs(query(collection(db, 'posts'), where('uid', '==', id))),
    getCountFromServer(query(collection(db, 'follows'), where('followee', '==', id))),
    getCountFromServer(query(collection(db, 'follows'), where('follower', '==', id)))
  ]);
  const posts = ps.docs.map(d => Object.assign({ id: d.id }, d.data())).sort((a, b) => (b.at || 0) - (a.at || 0));
  return { posts, followers: fr.data().count, following: fg.data().count };
}
function statsHtml(a, d) {
  return '<div class="profile-top">' + av(a, 84) + '<div class="stats"><div><b>' + d.posts.length + '</b><span>Postingan</span></div><div><b>' + d.followers + '</b><span>Pengikut</span></div><div><b>' + d.following + '</b><span>Mengikuti</span></div></div></div>';
}
async function vProfile() {
  const a = st.me, d = await profileData(st.uid);
  let h = statsHtml(a, d) + '<div class="bio"><div class="name">' + esc(a.name) + '</div><div class="sub">' + esc(a.breed) + '</div><div>' + esc(a.bio) + '</div></div>';
  h += '<div class="btn-row"><button class="btn ghost" data-act="editsheet">Edit profil</button><button class="btn" data-act="postsheet">Postingan baru</button><button class="btn ghost" data-act="logout">Keluar</button></div>';
  if (!d.posts.length) return h + '<div class="empty-state"><b>Belum ada postingan</b>Foto pertama kucingmu akan muncul di sini.</div>';
  return h + gridHtml(d.posts, a);
}
async function vOther() {
  const a = await getUser(st.other, true);
  if (!a) return '<div class="empty-state"><b>Akun tidak ditemukan</b></div>';
  const d = await profileData(a.id), f = st.follows.has(a.id);
  let h = statsHtml(a, d) + '<div class="bio"><div class="name">' + esc(a.name) + '</div><div class="sub">' + esc(a.breed) + '</div><div>' + esc(a.bio) + '</div></div>';
  h += '<div class="btn-row"><button class="btn' + (f ? ' ghost' : '') + '" data-act="follow" data-id="' + a.id + '">' + (f ? 'Mengikuti' : 'Ikuti') + '</button><button class="btn ghost" data-act="chat" data-id="' + a.id + '">Kirim pesan</button></div>';
  return h + (d.posts.length ? gridHtml(d.posts, a) : '<div class="empty-state"><b>Belum ada postingan</b></div>');
}
function vAuth() {
  const reg = st.authMode === 'register';
  const sample = { fur: FUR[st.regFur][0], belly: FUR[st.regFur][1], bg: BG[0], stripe: st.regFur === 0 };
  let h = '<div class="auth"><div class="auth-hero">' + av(reg ? sample : { fur: '#2b2b2e', belly: '#ffffff', bg: BG[0] }, 96) + '<h1>' + (reg ? 'Daftarkan kucingmu' : 'Selamat datang kembali') + '</h1><p>' + (reg ? 'Buat akun untuk kucingmu, lalu mulai berteman dengan kucing lain.' : 'Masuk untuk lanjut ke Meowgram.') + '</p></div>';
  h += '<div class="tabs" role="tablist"><button type="button" role="tab" data-act="authtab" data-v="register" aria-selected="' + reg + '">Daftar</button><button type="button" role="tab" data-act="authtab" data-v="login" aria-selected="' + !reg + '">Masuk</button></div><form id="af" novalidate>';
  if (reg) {
    h += '<div class="field"><label for="an">Nama kucing</label><input id="an" maxlength="24" placeholder="Misalnya: Mochi" autocomplete="off"></div><div class="field"><label for="ab">Ras (opsional)</label><input id="ab" maxlength="30" placeholder="Misalnya: Domestik" autocomplete="off"></div>';
    h += '<div class="field"><span>Warna bulu</span><div class="chips">' + FUR.map((f, i) => '<button type="button" class="swatch" style="background:' + f[0] + '" data-act="regfur" data-i="' + i + '" aria-label="Warna ' + (i + 1) + '" aria-pressed="' + (i === st.regFur) + '"></button>').join('') + '</div></div>';
  }
  h += '<div class="field"><label for="ae">Email pemilik</label><input id="ae" type="email" inputmode="email" autocomplete="email" placeholder="nama@email.com"></div>';
  h += '<div class="field"><label for="ap">Kata sandi</label><input id="ap" type="password" autocomplete="' + (reg ? 'new-password' : 'current-password') + '" placeholder="Minimal 6 karakter"></div>';
  return h + '<div class="err" id="aerr" role="alert"></div><button class="btn big" id="asub" type="submit">' + (reg ? 'Daftar dan mulai' : 'Masuk') + '</button></form></div>';
}
function vSetup() {
  return '<div class="setup"><h2 style="font-family:var(--font-display)">Firebase belum diisi</h2><p>Buka berkas <code>src/firebase-config.js</code>, isi dengan konfigurasi dari Firebase Console, lalu bangun ulang aplikasinya. Langkah lengkap ada di <code>PANDUAN.md</code>.</p></div>';
}

async function render(keep) {
  const t = ++tok, top = $('top'), main = $('main'), nav = $('nav'), sc = main.scrollTop;
  const themeBtn = '<button class="icon-btn" data-act="theme" aria-label="Ganti tema terang atau gelap">' + ic(isDark() ? 'sun' : 'moon') + '</button>';
  const logo = '<div class="logo">meow<span>gram</span></div>';
  if (unsubChat && !(st.uid && st.chat)) { unsubChat(); unsubChat = null; }
  if (!configured) { top.innerHTML = logo + themeBtn; nav.hidden = true; main.innerHTML = vSetup(); return; }
  if (!st.ready) { top.innerHTML = logo; nav.hidden = true; main.innerHTML = '<div class="empty-state">Memuat...</div>'; return; }
  if (!st.uid) { top.innerHTML = logo + themeBtn; nav.hidden = true; main.innerHTML = vAuth(); main.scrollTop = 0; return; }
  nav.hidden = false;
  const back = '<button class="icon-btn" data-act="back" aria-label="Kembali">' + ic('back') + '</button>';
  let view;
  if (st.chat) {
    const p = await getUser(st.chat);
    if (t !== tok) return;
    top.innerHTML = back + '<div class="row" style="padding:0;flex:1;min-width:0">' + av(p, 32) + '<div class="title">' + esc(p.name) + '</div></div>' + themeBtn;
    main.innerHTML = '<div class="chat"><div class="chat-body" id="cb"><div class="sub" style="text-align:center">Memuat pesan...</div></div><form class="chat-in" id="cf"><input id="ci" placeholder="Tulis pesan" autocomplete="off" aria-label="Pesan"><button class="btn" type="submit">Kirim</button></form></div>';
    subChat();
  } else {
    if (st.other) { top.innerHTML = back + '<div class="title" style="flex:1">Profil kucing</div>' + themeBtn; view = vOther; }
    else {
      top.innerHTML = ({ home: logo, search: '<div class="title">Cari</div>', dm: '<div class="title">Pesan</div>', profile: '<div class="title">' + esc(st.me.name) + '</div>' }[st.tab] || logo) + themeBtn;
      view = { home: vHome, search: vSearch, dm: vDm, profile: vProfile }[st.tab];
    }
    if (!keep) main.innerHTML = '<div class="empty-state">Memuat...</div>';
    let html;
    try { html = await view(); } catch (e) { html = '<div class="empty-state"><b>Tidak bisa memuat</b>' + esc(errText(e)) + '<br><button class="btn" data-act="reload">Coba lagi</button></div>'; }
    if (t !== tok) return;
    main.innerHTML = html; main.scrollTop = keep ? sc : 0;
  }
  nav.innerHTML = ['home', 'search', 'post', 'dm', 'profile'].map(k => {
    const cur = !st.chat && !st.other && st.tab === k;
    const icon = { home: 'home', search: 'search', post: 'plus', dm: 'dm', profile: 'user' }[k];
    const lab = { home: 'Beranda', search: 'Cari', post: 'Buat postingan', dm: 'Pesan', profile: 'Profil' }[k];
    return '<button data-act="nav" data-v="' + k + '" aria-label="' + lab + '" aria-current="' + cur + '">' + ic(icon) + '</button>';
  }).join('');
}
function subChat() {
  if (unsubChat) unsubChat();
  unsubChat = onSnapshot(query(collection(db, 'chats', cid(st.chat), 'messages'), orderBy('at'), limit(200)), snap => {
    const cb = $('cb'); if (!cb) return;
    cb.innerHTML = snap.docs.map(d => { const m = d.data(); return '<div class="msg' + (m.from === st.uid ? ' me' : '') + '">' + esc(m.text) + '</div>'; }).join('') || '<div class="sub" style="text-align:center;margin-top:12px">Belum ada pesan. Sapa dengan meong.</div>';
    cb.scrollTop = cb.scrollHeight;
  }, () => toast('Tidak bisa memuat pesan'));
}

/* ---------- sheet ---------- */
function openSheet(h) { $('sheet').innerHTML = '<div class="grab"></div>' + h; $('scrim').hidden = false; }
function closeSheet() { $('scrim').hidden = true; $('sheet').innerHTML = ''; }
const chips = (name, list, sel) => '<div class="chips">' + list.map(x => '<button type="button" class="chip" data-act="pick" data-g="' + name + '" data-v="' + esc(x) + '" aria-pressed="' + (x === sel) + '">' + esc(x) + '</button>').join('') + '</div>';
function previewHtml() { return draft.img ? '<img src="' + draft.img + '" alt="Foto yang dipilih">' : face(st.me, draft.prop, draft.bg); }
function postSheet() {
  draft = { bg: BG[2], prop: 'benang', img: '' };
  openSheet('<h2>Postingan baru</h2><div class="pic" id="pv" style="border-radius:14px;overflow:hidden;margin-bottom:12px">' + previewHtml() + '</div>' +
    '<button type="button" class="btn ghost big" data-act="pickphoto" style="margin-bottom:14px">Pilih foto dari galeri</button><input class="hidden-input" id="pf" type="file" accept="image/*">' +
    '<div id="illus"><div class="field"><span>Atau pakai gambar kucingmu: latar</span><div class="chips">' + BG.map((b, i) => '<button type="button" class="swatch" style="background:' + b + '" data-act="pick" data-g="bg" data-v="' + b + '" aria-label="Latar ' + (i + 1) + '" aria-pressed="' + (b === draft.bg) + '"></button>').join('') + '</div></div>' +
    '<div class="field"><span>Properti</span><div class="chips">' + [['benang', 'Benang'], ['ikan', 'Ikan'], ['kardus', 'Kardus'], ['hati', 'Hati'], ['', 'Polos']].map(p => '<button type="button" class="chip" data-act="pick" data-g="prop" data-v="' + p[0] + '" aria-pressed="' + (p[0] === draft.prop) + '">' + p[1] + '</button>').join('') + '</div></div></div>' +
    '<div class="field"><label for="pc">Keterangan</label><textarea id="pc" rows="2" maxlength="300" placeholder="Tulis sesuatu tentang kucingmu"></textarea></div><button class="btn big" id="dopost" data-act="dopost">Bagikan</button>');
}
function noteSheet() {
  const n = noteFresh(st.me.note) ? st.me.note : null;
  draft = { music: n ? n.music : '', place: n ? n.place : '' };
  openSheet('<h2>Note baru</h2><div class="field"><label for="nt">Tulis note</label><input id="nt" maxlength="40" placeholder="Misalnya: Lagi mager" value="' + esc(n ? n.text : '') + '"></div>' +
    '<div class="field"><span>Musik (opsional)</span>' + chips('music', MUSIC, draft.music) + '</div><div class="field"><span>Lokasi kucing (opsional)</span>' + chips('place', PLACES, draft.place) + '</div>' +
    '<button class="btn big" data-act="donote">Bagikan note</button>' + (n ? '<button class="btn big ghost" style="margin-top:8px" data-act="delnote">Hapus note</button>' : ''));
}
function editSheet() {
  const m = st.me; draft = { fur: m.fur, belly: m.belly };
  openSheet('<h2>Edit profil kucing</h2><div class="field"><label for="en">Nama akun kucing</label><input id="en" maxlength="24" value="' + esc(m.name) + '"></div><div class="field"><label for="eb">Ras</label><input id="eb" maxlength="30" value="' + esc(m.breed) + '"></div>' +
    '<div class="field"><span>Warna bulu</span><div class="chips">' + FUR.map((f, i) => '<button type="button" class="swatch" style="background:' + f[0] + '" data-act="pick" data-g="fur" data-v="' + f[0] + '|' + f[1] + '" aria-label="Warna ' + (i + 1) + '" aria-pressed="' + (f[0] === draft.fur) + '"></button>').join('') + '</div></div>' +
    '<div class="field"><label for="ebio">Bio</label><textarea id="ebio" rows="2" maxlength="90">' + esc(m.bio) + '</textarea></div><button class="btn big" data-act="doedit">Simpan</button>');
}
function compress(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => {
      const im = new Image();
      im.onload = () => {
        const s = Math.min(1, 900 / Math.max(im.width, im.height)), c = document.createElement('canvas');
        c.width = Math.round(im.width * s); c.height = Math.round(im.height * s);
        c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
        let q = 0.72, d = c.toDataURL('image/jpeg', q);
        while (d.length > 700000 && q > 0.3) { q -= 0.1; d = c.toDataURL('image/jpeg', q); }
        res(d);
      };
      im.onerror = rej; im.src = r.result;
    };
    r.onerror = rej; r.readAsDataURL(file);
  });
}

/* ---------- aksi ---------- */
async function boot(user) {
  st.uid = user.uid;
  let me = await getUser(user.uid, true);
  if (!me) {
    const nm = (user.email || 'kucingku').split('@')[0].toLowerCase().replace(/[^a-z0-9.]/g, '.').slice(0, 24) || 'kucingku';
    await setDoc(doc(db, 'users', user.uid), { name: nm, breed: 'Domestik', bio: 'Baru bergabung di Meowgram.', fur: FUR[0][0], belly: FUR[0][1], bg: BG[0], stripe: 1, note: null, at: Date.now() });
    me = await getUser(user.uid, true);
  }
  st.me = me;
  const f = await getDocs(query(collection(db, 'follows'), where('follower', '==', user.uid)));
  st.follows = new Set(f.docs.map(d => d.data().followee));
  st.home = st.follows.size ? 'feed' : 'fyp'; st.tab = 'home'; st.chat = null; st.other = null;
}
async function doAuth() {
  const em = $('ae').value.trim().toLowerCase(), pw = $('ap').value, reg = st.authMode === 'register', nm = reg ? $('an').value.trim() : '', err = $('aerr'), btn = $('asub');
  if (!/^\S+@\S+\.\S+$/.test(em)) { err.textContent = 'Format email belum benar.'; return; }
  if (pw.length < 6) { err.textContent = 'Kata sandi minimal 6 karakter.'; return; }
  if (reg && !nm) { err.textContent = 'Nama kucing wajib diisi.'; return; }
  err.textContent = ''; btn.disabled = true;
  try {
    if (reg) {
      registering = true;
      const cred = await createUserWithEmailAndPassword(auth, em, pw), f = FUR[st.regFur];
      await setDoc(doc(db, 'users', cred.user.uid), { name: nm.replace(/\s+/g, '.').toLowerCase(), breed: $('ab').value.trim() || 'Domestik', bio: 'Baru bergabung di Meowgram.', fur: f[0], belly: f[1], bg: BG[nm.length % BG.length], stripe: st.regFur === 0 ? 1 : 0, note: null, at: Date.now() });
      await boot(cred.user); registering = false;
    } else {
      await signInWithEmailAndPassword(auth, em, pw);
    }
    render();
  } catch (e) { registering = false; err.textContent = errText(e); btn.disabled = false; }
}
async function act(a, el) {
  const id = el.dataset.id;
  if (a === 'nav') { if (el.dataset.v === 'post') { postSheet(); return; } st.tab = el.dataset.v; st.chat = null; st.other = null; render(); }
  else if (a === 'htab') { st.home = el.dataset.v; render(); }
  else if (a === 'theme') { setTheme(isDark() ? 'light' : 'dark'); render(true); }
  else if (a === 'back') { st.chat = null; st.other = null; render(); }
  else if (a === 'open') { st.other = id; st.chat = null; render(); }
  else if (a === 'reload') render();
  else if (a === 'toast') toast(el.dataset.t);
  else if (a === 'authtab') { st.authMode = el.dataset.v; render(); }
  else if (a === 'regfur') { st.regFur = +el.dataset.i; const vals = { an: ($('an') || {}).value, ab: ($('ab') || {}).value, ae: ($('ae') || {}).value }; render(); Object.keys(vals).forEach(k => { if ($(k) && vals[k]) $(k).value = vals[k]; }); }
  else if (a === 'logout') { await signOut(auth); st.uid = null; st.me = null; st.authMode = 'login'; render(); toast('Kamu sudah keluar'); }
  else if (a === 'chat') { st.chat = id; st.other = null; st.tab = 'dm'; await setDoc(doc(db, 'chats', cid(id)), { members: [st.uid, id] }, { merge: true }); render(); }
  else if (a === 'like') {
    const ref = doc(db, 'posts', el.dataset.k), was = el.dataset.l === '1';
    await updateDoc(ref, { likedBy: was ? arrayRemove(st.uid) : arrayUnion(st.uid) }); render(true);
  }
  else if (a === 'delpost') { await deleteDoc(doc(db, 'posts', el.dataset.k)); toast('Postingan dihapus'); render(true); }
  else if (a === 'follow') {
    const ref = doc(db, 'follows', st.uid + '_' + id), was = st.follows.has(id);
    if (was) { await deleteDoc(ref); st.follows.delete(id); } else { await setDoc(ref, { follower: st.uid, followee: id }); st.follows.add(id); }
    toast(was ? 'Berhenti mengikuti' : 'Sekarang kamu mengikuti');
    if (st.tab === 'search' && !st.other && $('results')) $('results').innerHTML = resultsHtml(st.q.trim().toLowerCase()); else render(true);
  }
  else if (a === 'postsheet') postSheet();
  else if (a === 'notesheet') noteSheet();
  else if (a === 'editsheet') editSheet();
  else if (a === 'pickphoto') $('pf').click();
  else if (a === 'pick') {
    const g = el.dataset.g, v = el.dataset.v;
    if (g === 'music' || g === 'place') draft[g] = draft[g] === v ? '' : v;
    else if (g === 'fur') { const p = v.split('|'); draft.fur = p[0]; draft.belly = p[1]; }
    else { draft[g] = v; draft.img = ''; }
    if (g === 'bg' || g === 'prop') $('pv').innerHTML = previewHtml();
    const sel = g === 'fur' ? draft.fur : draft[g];
    $('sheet').querySelectorAll('[data-g="' + g + '"]').forEach(b => b.setAttribute('aria-pressed', String((g === 'fur' ? b.dataset.v.split('|')[0] : b.dataset.v) === sel)));
  }
  else if (a === 'dopost') {
    el.disabled = true;
    try {
      const data = { uid: st.uid, cap: $('pc').value.trim() || 'Hari pertama di Meowgram.', bg: draft.bg, prop: draft.prop, likedBy: [], at: Date.now() };
      if (draft.img) data.img = draft.img;
      await addDoc(collection(db, 'posts'), data);
      closeSheet(); st.tab = 'profile'; st.chat = null; st.other = null; render(); toast('Postingan dibagikan');
    } catch (e) { el.disabled = false; toast(errText(e)); }
  }
  else if (a === 'donote') {
    const t = $('nt').value.trim();
    if (!t && !draft.music && !draft.place) { toast('Isi teks, musik, atau lokasi dulu'); return; }
    const note = { text: t, music: draft.music || '', place: draft.place || '', at: Date.now() };
    await updateDoc(doc(db, 'users', st.uid), { note }); st.me.note = note; st.users[st.uid] = st.me; closeSheet(); render(true); toast('Note dibagikan selama 24 jam');
  }
  else if (a === 'delnote') { await updateDoc(doc(db, 'users', st.uid), { note: null }); st.me.note = null; closeSheet(); render(true); }
  else if (a === 'doedit') {
    const n = $('en').value.trim().replace(/\s+/g, '.').toLowerCase();
    if (!n) { toast('Nama kucing wajib diisi'); return; }
    const patch = { name: n, breed: $('eb').value.trim() || 'Domestik', bio: $('ebio').value.trim(), fur: draft.fur, belly: draft.belly };
    await updateDoc(doc(db, 'users', st.uid), patch); Object.assign(st.me, patch); closeSheet(); render(); toast('Profil kucing disimpan');
  }
}

document.addEventListener('click', e => {
  if (e.target.id === 'scrim') { closeSheet(); return; }
  const el = e.target.closest('[data-act]');
  if (!el) return;
  act(el.dataset.act, el).catch(err => { toast(errText(err)); });
});
document.addEventListener('input', e => {
  if (e.target.id === 'q') { st.q = e.target.value; $('results').innerHTML = resultsHtml(st.q.trim().toLowerCase()); }
});
document.addEventListener('change', async e => {
  if (e.target.id === 'pf' && e.target.files && e.target.files[0]) {
    try { draft.img = await compress(e.target.files[0]); $('pv').innerHTML = previewHtml(); $('illus').style.opacity = '.45'; }
    catch (err) { toast('Foto tidak bisa dibaca'); }
  }
});
document.addEventListener('submit', async e => {
  if (e.target.id === 'af') { e.preventDefault(); doAuth(); return; }
  if (e.target.id === 'cf') {
    e.preventDefault();
    const i = $('ci'), t = i.value.trim(); if (!t) return;
    i.value = '';
    try {
      const id = cid(st.chat);
      await addDoc(collection(db, 'chats', id, 'messages'), { from: st.uid, text: t, at: Date.now() });
      await setDoc(doc(db, 'chats', id), { members: [st.uid, st.chat], lastText: t, lastAt: Date.now(), lastFrom: st.uid }, { merge: true });
    } catch (err) { toast(errText(err)); }
  }
});
document.addEventListener('keydown', e => { if (e.key === 'Escape' && !$('scrim').hidden) closeSheet(); });

try { const s = localStorage.getItem('mg-theme'); if (s === 'dark' || s === 'light') { document.documentElement.setAttribute('data-theme', s); st.theme = s; } } catch (e) { /* abaikan */ }

if (configured) {
  onAuthStateChanged(auth, async u => {
    if (registering) return;
    try { if (u) await boot(u); else { st.uid = null; st.me = null; } } catch (e) { toast(errText(e)); }
    st.ready = true; render();
  });
}
render();
