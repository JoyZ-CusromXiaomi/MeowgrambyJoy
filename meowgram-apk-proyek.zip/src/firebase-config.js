// Konfigurasi Firebase proyek meowgram-by-joyz.
// Konfigurasi ini memang boleh ada di dalam aplikasi, keamanan data dijaga oleh aturan Firestore.
export default {
  apiKey: "AIzaSyAVTv-6Gfjf91cbY67XVXCbr-np5F4gL1E",
  authDomain: "meowgram-by-joyz-ede09.firebaseapp.com",
  projectId: "meowgram-by-joyz-ede09",
  storageBucket: "meowgram-by-joyz-ede09.firebasestorage.app",
  messagingSenderId: "561961485444",
  appId: "1:561961485444:web:ef43f388ce391033ab2ed1",
  measurementId: "G-EHBE2K0ZRG"
};
